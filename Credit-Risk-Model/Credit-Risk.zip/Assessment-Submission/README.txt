This folder contains 3 ipynb files :

1) Part_1_EDA.ipynb -> Exploratory Data Analysis
2) Part_2_LR_Model.ipynb -> Logistic Regression Model
3) Part_2_ANN_Model.ipynb -> Artificial Neural Network Model

